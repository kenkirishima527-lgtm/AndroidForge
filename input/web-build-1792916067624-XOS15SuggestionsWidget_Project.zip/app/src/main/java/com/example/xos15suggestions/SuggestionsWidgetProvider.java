package com.example.xos15suggestions;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.widget.RemoteViews;

public class SuggestionsWidgetProvider extends AppWidgetProvider {
    private static final String[] PACKAGES = {
        "com.tencent.ig",                    // PUBG Mobile Global
        "com.google.android.youtube",        // YouTube
        "com.zhiliaoapp.musically",           // TikTok
        "com.facebook.orca"                  // Messenger
    };
    private static final int[] VIEW_IDS = {
        R.id.shortcut_pubg, R.id.shortcut_youtube,
        R.id.shortcut_tiktok, R.id.shortcut_messenger
    };

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int widgetId : appWidgetIds) updateWidget(context, manager, widgetId);
    }

    private void updateWidget(Context context, AppWidgetManager manager, int widgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.suggestions_widget);
        PackageManager pm = context.getPackageManager();

        for (int i = 0; i < VIEW_IDS.length; i++) {
            Intent launch = pm.getLaunchIntentForPackage(PACKAGES[i]);
            if (launch == null) {
                // If the app is not installed, open its Play Store listing/search instead.
                launch = new Intent(Intent.ACTION_VIEW,
                    android.net.Uri.parse("https://play.google.com/store/search?q=" + PACKAGES[i] + "&c=apps"));
            }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent pending = PendingIntent.getActivity(
                context, 100 + i, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            views.setOnClickPendingIntent(VIEW_IDS[i], pending);
        }
        manager.updateAppWidget(widgetId, views);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(intent.getAction())) {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            int[] ids = manager.getAppWidgetIds(new ComponentName(context, SuggestionsWidgetProvider.class));
            for (int id : ids) updateWidget(context, manager, id);
        }
    }
}
