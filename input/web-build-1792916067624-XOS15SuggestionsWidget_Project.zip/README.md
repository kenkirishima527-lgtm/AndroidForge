# XOS-style Suggestions Widget (Android)

This is an installable Android Studio project for a **custom widget inspired by** the XOS 15 Suggestions card. It is not an official Infinix/XOS component and does not replace the system launcher.

## Features
- Home-screen app widget with a dark translucent purple card.
- Four tap targets: PUBG Mobile Global, YouTube, TikTok, and Messenger.
- Opens the matching app if installed; otherwise opens a Google Play search.
- No special permissions requested.

## Build an APK
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose **Build > Build APK(s)**.
5. The debug APK will be under `app/build/outputs/apk/debug/app-debug.apk`.

## Install and add the widget
1. Transfer `app-debug.apk` to your Infinix Smart 10 Plus and install it. If Android asks, allow installation from that file manager for this APK.
2. Long-press the home screen and tap **Widgets**.
3. Find **XOS-style Suggestions** and drag it to the home screen.
4. Resize it if your launcher permits.

## Notes
- This project source is provided; it is not a precompiled APK.
- The shortcut package ID for PUBG is the Global version (`com.tencent.ig`). Other regional versions may need a package ID change in `SuggestionsWidgetProvider.java`.
- If XOS Launcher does not list third-party widgets, try the launcher’s widget picker after a restart. Compatibility depends on the installed launcher.
