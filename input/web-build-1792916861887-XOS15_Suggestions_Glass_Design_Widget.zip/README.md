# XOS 15 Suggestions-style Android Widget

A native Android home-screen widget inspired by the glassy navy/teal XOS 15 concept shown in the design mockup. It includes PUBG Mobile Global, YouTube, TikTok, Messenger, and More shortcuts, plus a "Make life easier" footer.

## Build
Upload this source ZIP to AndroidForge and choose Android (APK), build variant `auto`. This is a community-made inspired design, not an official Infinix/XOS component.

## Add the widget
After installing the APK, long-press an empty area on the home screen, open Widgets, find **XOS 15 Suggestions**, then drag it onto the home screen. Resize it wider/taller if the launcher allows it.

## Notes
- App shortcuts open installed apps where package names match. If an app is missing, its Play Store search page opens.
- The visual uses native Android RemoteViews, so some gradients/glass effects are approximated rather than exact.
