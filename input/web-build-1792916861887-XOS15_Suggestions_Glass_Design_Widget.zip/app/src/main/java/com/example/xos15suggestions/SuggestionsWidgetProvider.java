package com.example.xos15suggestions;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.widget.RemoteViews;

public class SuggestionsWidgetProvider extends AppWidgetProvider {
    private static final String[] PACKAGES = {
        "com.tencent.ig",
        "com.google.android.youtube",
        "com.zhiliaoapp.musically",
        "com.facebook.orca"
    };
    private static final int[] VIEW_IDS = {
        R.id.shortcut_pubg,
        R.id.shortcut_youtube,
        R.id.shortcut_tiktok,
        R.id.shortcut_messenger
    };

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int widgetId : appWidgetIds) updateWidget(context, manager, widgetId);
    }

    private void updateWidget(Context context, AppWidgetManager manager, int widgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.suggestions_widget);
        PackageManager pm = context.getPackageManager();

        for (int i = 0; i < VIEW_IDS.length; i++) {
            Intent launch = pm.getLaunchIntentForPackage(PACKAGES[i]);
            if (launch == null) {
                launch = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/search?q=" + Uri.encode(PACKAGES[i]) + "&c=apps"));
            }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent pending = PendingIntent.getActivity(
                context, 200 + i, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            views.setOnClickPendingIntent(VIEW_IDS[i], pending);
        }

        Intent more = new Intent(Intent.ACTION_VIEW,
            Uri.parse("https://play.google.com/store/search?q=popular%20apps&c=apps"));
        PendingIntent morePending = PendingIntent.getActivity(
            context, 250, more,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        views.setOnClickPendingIntent(R.id.shortcut_more, morePending);
        manager.updateAppWidget(widgetId, views);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(intent.getAction())) {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            int[] ids = manager.getAppWidgetIds(new ComponentName(context, SuggestionsWidgetProvider.class));
            for (int id : ids) updateWidget(context, manager, id);
        }
    }
}
